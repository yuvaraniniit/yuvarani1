package com.dao;

import java.util.List;

import com.model.Newuser;

public interface RegisterDAO {

 public void sa(Newuser newuser);

public List<Newuser> getUsername();

}
