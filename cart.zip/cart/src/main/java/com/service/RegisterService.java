package com.service;

import java.util.List;

import com.model.Newuser;

public interface RegisterService {

public void s(Newuser newuser);

public List<Newuser> getuser();
}
